package barnestr;

import java.util.List;

public class ForEachLinkedStrategy implements AutoCompleter{
    @Override
    public void initialize(String filename) {

    }

    @Override
    public List allThatBeginsWith(String prefix) {
        return null;
    }

    @Override
    public long getLastOperationTime() {
        return 0;
    }
}
