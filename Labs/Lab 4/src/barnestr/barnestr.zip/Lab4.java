package barnestr;

public class Lab4 {
    public static void main(String[] args) {

    }
}
