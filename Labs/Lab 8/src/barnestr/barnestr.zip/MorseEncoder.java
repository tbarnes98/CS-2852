package barnestr;

public class MorseEncoder {

}
