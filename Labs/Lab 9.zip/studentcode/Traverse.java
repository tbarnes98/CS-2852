package studentcode;

/**
 * A Functional Interface that implements a specific action taken when doing
 * a traversal of a Huffman Tree and visiting a leaf node.
 */
@FunctionalInterface
interface Traverse {
    void process(HuffmanTreeUtilities.HuffmanLeaf leaf, StringBuffer sb);
}
