/*
 * CS2852
 * Fall 2018
 * Lab 2 - Connect the Dots Generator
 * Name: Trevor Barnes
 * Created: 9/11/18
 */
package barnestr;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * A class named Picture that represents the entire image drawn on a JavaFX Canvas.
 * This class has an ArrayList of dots loaded in from a .dot file.
 * Dots and lines can also be drawn with the methods in this class.
 *
 * @author Trevor Barnes
 * @version 1.0
 */
public class Picture {

    private static final int CANVAS_SIZE = 720;
    private static final int DOT_SIZE = 8;

    private List<Dot> dots = new ArrayList<>();
    private Picture original;

    /**
     * The constructor for Picture that initializes the dots list
     *
     * @param emptyList the list of dots passed in
     */
    public Picture(List<Dot> emptyList) {
        this.dots = emptyList;
    }

    /**
     * The constructor for Picture that initializes the dots list and original Picture object
     *
     * @param original  the original Picture with the original dots
     * @param emptyList the list of dots passed in
     */
    public Picture(Picture original, List<Dot> emptyList) {
        this.dots = emptyList;
        this.original = original;
    }

    /**
     * Loads in a .dot file's data into the ArrayList of Dots.
     *
     * @param file the .dot file with dot coordinates
     * @throws FileNotFoundException if file is not found
     */
    public void load(File file) throws FileNotFoundException {

        try (Scanner in = new Scanner(file)) {
            do {
                String coord = in.nextLine();
                double x = Double.parseDouble(coord.substring(0, coord.indexOf(","))) *
                        CANVAS_SIZE;
                double y = Math.abs((Double.parseDouble(coord.
                        substring(coord.indexOf(",") + 1)) * CANVAS_SIZE) - CANVAS_SIZE);
                dots.add(new Dot(x, y));
                original.dots.add(new Dot(x, y));
            } while (in.hasNext());
        }
    }

    /**
     * Saves the data of the dots ArrayList in a given file location as a .dot file
     *
     * @param file the file to be saved to
     * @throws FileNotFoundException if file is not found
     */
    public void save(File file) throws FileNotFoundException {
        try (PrintWriter pw = new PrintWriter(file)) {
            for (int i = 0; i < dots.size(); i++) {
                pw.append(String.valueOf((dots.get(i).getX()) / CANVAS_SIZE));
                pw.append(", ");
                pw.append(String.valueOf(Math.abs(dots.get(i).getY() - CANVAS_SIZE) /
                        CANVAS_SIZE));
                pw.append("\r\n");
            }
        }
    }

    /**
     * Draws the dots using the Canvas's GraphicsContext
     *
     * @param canvas the canvas to be drawn on
     */
    public void drawDots(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();

        gc.setFill(Color.BLACK);

        for (int i = dots.size() - 1; i > 0; i--) {
            gc.fillOval(dots.get(i).getX() - (DOT_SIZE / 2),
                    dots.get(i).getY() - (DOT_SIZE / 2), DOT_SIZE, DOT_SIZE);
        }
    }

    /**
     * Sets the number of dots on the image by each dots determined critical value.
     * The dot with the lowest critical value is removed until the number of
     * desired dots is reached.
     *
     * @param numberDesired the number of dots requested by the user
     */
    public void removeDots(int numberDesired) {
        dots.clear();
        for (Dot dot : original.dots) {
            dots.add(dot);
        }
        if (numberDesired > 3) {
            int removedCount = dots.size() - numberDesired;
            for (int i = 0; i < removedCount; i++) {
                double[] cv = new double[dots.size()];
                for (int j = 0; j < dots.size(); j++) {
                    if (j == 0) {
                        cv[j] = dots.get(j).calculateCriticalValue(dots
                                .get(dots.size() - 1), dots.get(j + 1));
                    } else if (j == dots.size() - 1) {
                        cv[j] = dots.get(j).calculateCriticalValue(dots
                                .get(j - 1), dots.get(0));
                    } else {
                        cv[j] = dots.get(j).calculateCriticalValue(dots
                                .get(j - 1), dots.get(j + 1));
                    }
                }
                int index = 0;
                double minCValue = cv[index];
                for (int k = 0; k < cv.length; k++) {
                    if (cv[k] < minCValue) {
                        minCValue = cv[k];
                        index = k;
                        System.out.println(cv[k]);
                    }
                }
                dots.remove(index);
            }
        }
    }

    /**
     * Draws the lines of one dot to the next in the ArrayList using the Canvas's GraphicsContext.
     *
     * @param canvas the canvas to be drawn on
     */
    public void drawLines(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.beginPath();

        for (int i = dots.size() - 1; i > 0; i--) {
            gc.beginPath();
            gc.moveTo(dots.get(i).getX(), dots.get(i).getY());
            if (i + 1 < dots.size()) {
                gc.lineTo(dots.get(i + 1).getX(), dots.get(i + 1).getY());
            } else {
                gc.lineTo(dots.get(1).getX(), dots.get(1).getY());
            }
            gc.closePath();
            gc.stroke();
        }
    }

    /**
     * Clears the canvas by using the clearReact method for GraphicsContext.
     *
     * @param canvas the canvas to be cleared
     */
    public void clearCanvas(Canvas canvas) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.clearRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);
    }

}
